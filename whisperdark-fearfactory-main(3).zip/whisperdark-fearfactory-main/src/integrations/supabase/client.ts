
import { createClient } from '@supabase/supabase-js';
import type { Database } from './types';

const SUPABASE_URL = "https://bntyqlqvyrmtmfdirddi.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJudHlxbHF2eXJtdG1mZGlyZGRpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE1NTg3NzIsImV4cCI6MjA1NzEzNDc3Mn0.JQSc3IDhpbbRgP84LeeKkw6AfgfiY_ksEvJo8BQspvw";

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_ANON_KEY);

// Funciones auxiliares para la autenticación
export const signUp = async (email: string, password: string, userData: any) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: userData,
    }
  });
  return { data, error };
};

export const signIn = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  return { data, error };
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  return { error };
};

export const getCurrentUser = async () => {
  const { data, error } = await supabase.auth.getUser();
  return { data, error };
};
