
import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import Index from "./pages/Index";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Subscription from "./pages/Subscription";
import Challenges from "./pages/Challenges";
import NotFound from "./pages/NotFound";
import Feed from "./pages/Feed";
import Creepypasta from "./pages/Creepypasta";
import HauntedMap from "./pages/HauntedMap";
import { AuthProvider, useAuth } from "./context/AuthContext";
import NavBar from "./components/NavBar";

const queryClient = new QueryClient();

// Componente para rutas protegidas
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="min-h-screen bg-horror-gradient flex items-center justify-center">
      <p className="text-foreground">Cargando...</p>
    </div>;
  }
  
  if (!user) {
    return <Navigate to="/login" />;
  }
  
  return <>{children}</>;
};

// Componente para manejar el desplazamiento al cambiar de ruta
const ScrollToTop = () => {
  const { pathname } = useLocation();

  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
};

// Componente principal de la aplicación
const AppContent = () => (
  <div className="relative">
    {/* Capa de ruido visual para toda la aplicación */}
    <div className="noise-bg fixed inset-0 pointer-events-none z-[1000]"></div>
    
    {/* Contenido de la aplicación */}
    <BrowserRouter>
      <ScrollToTop />
      <NavBar />
      <main className="pt-16"> {/* Añadimos padding-top para compensar la navbar fija */}
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/feed" element={
            <ProtectedRoute>
              <Feed />
            </ProtectedRoute>
          } />
          <Route path="/creepypasta" element={
            <ProtectedRoute>
              <Creepypasta />
            </ProtectedRoute>
          } />
          <Route path="/haunted-map" element={
            <ProtectedRoute>
              <HauntedMap />
            </ProtectedRoute>
          } />
          <Route path="/challenges" element={
            <ProtectedRoute>
              <Challenges />
            </ProtectedRoute>
          } />
          <Route path="/subscription" element={
            <ProtectedRoute>
              <Subscription />
            </ProtectedRoute>
          } />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
    </BrowserRouter>
    
    <Toaster />
    <Sonner />
  </div>
);

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
