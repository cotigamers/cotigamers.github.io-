
import React from 'react';
import { Button } from '@/components/ui/button';

interface CreepypastaCardProps {
  title: string;
  excerpt: string;
  author: string;
}

const CreepypastaCard = ({ title, excerpt, author }: CreepypastaCardProps) => (
  <div className="horror-card">
    <h3 className="text-lg font-horror-subtitle mb-2">{title}</h3>
    <p className="text-horror-mist mb-4 line-clamp-3">{excerpt}</p>
    <div className="flex justify-between items-center">
      <span className="text-sm text-horror-mist">Por: {author}</span>
      <Button variant="outline" size="sm" className="horror-button">
        Leer más
      </Button>
    </div>
  </div>
);

export default CreepypastaCard;
