
import React from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Ghost } from 'lucide-react';

interface StoryEditorProps {
  storyStart: string;
  setStoryStart: (value: string) => void;
  handleGenerateStory: () => void;
  isGenerating: boolean;
}

const StoryEditor = ({ storyStart, setStoryStart, handleGenerateStory, isGenerating }: StoryEditorProps) => {
  return (
    <div className="horror-card">
      <h2 className="text-xl font-horror-subtitle mb-4">
        Comienza tu historia de terror
      </h2>
      <Textarea
        placeholder="Escribe el inicio de tu historia de terror (mínimo 2 frases)..."
        className="horror-input resize-none w-full min-h-[150px] mb-4"
        value={storyStart}
        onChange={(e) => setStoryStart(e.target.value)}
      />
      <Button 
        onClick={handleGenerateStory} 
        className="w-full horror-button"
        disabled={isGenerating}
      >
        <Ghost className="w-5 h-5 mr-2" />
        {isGenerating ? 'Generando historia...' : 'Generar historia con IA'}
      </Button>
    </div>
  );
};

export default StoryEditor;
