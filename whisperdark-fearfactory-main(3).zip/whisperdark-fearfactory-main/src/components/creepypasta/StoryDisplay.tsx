
import React from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { BookOpen, Headphones, Edit, Share2, Ghost } from 'lucide-react';

interface StoryDisplayProps {
  title: string;
  setTitle: (value: string) => void;
  generatedStory: string;
  handleSaveStory: () => void;
  handleNarrateStory: () => void;
  handleEditStory: () => void;
  handleCreateNewStory: () => void;
}

const StoryDisplay = ({ 
  title, 
  setTitle, 
  generatedStory, 
  handleSaveStory,
  handleNarrateStory,
  handleEditStory,
  handleCreateNewStory
}: StoryDisplayProps) => {
  return (
    <div className="horror-card">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-horror-subtitle">
          <BookOpen className="w-5 h-5 inline-block mr-2 text-horror-accent" />
          Tu Creepypasta
        </h2>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="horror-button"
            onClick={handleEditStory}
          >
            <Edit className="w-4 h-4 mr-1" />
            Editar
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            className="horror-button"
            onClick={handleNarrateStory}
          >
            <Headphones className="w-4 h-4 mr-1" />
            Narrar
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            className="horror-button"
          >
            <Share2 className="w-4 h-4 mr-1" />
            Compartir
          </Button>
        </div>
      </div>
      
      <div className="mb-4">
        <Label htmlFor="title">Título de tu historia</Label>
        <Input
          id="title"
          placeholder="Añade un título terrorífico..."
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="horror-input"
        />
      </div>
      
      <div className="bg-horror-dark/30 p-5 rounded-lg border border-horror-mist/20">
        <p className="text-foreground whitespace-pre-line leading-relaxed font-horror-base">
          {generatedStory}
        </p>
      </div>
      
      <div className="mt-6 flex gap-3 justify-center">
        <Button 
          onClick={handleSaveStory} 
          className="horror-button"
        >
          <Ghost className="w-5 h-5 mr-2" />
          Guardar historia
        </Button>
        <Button 
          onClick={handleCreateNewStory} 
          variant="outline"
          className="horror-button"
        >
          Crear otra historia
        </Button>
      </div>
    </div>
  );
};

export default StoryDisplay;
