
import React from 'react';
import CreepypastaCard from './CreepypastaCard';

const PopularCreepypastas = () => {
  return (
    <div className="mt-10">
      <h2 className="text-2xl font-horror-subtitle mb-6 text-center">
        Creepypastas Populares
      </h2>
      <div className="grid md:grid-cols-2 gap-6">
        <CreepypastaCard 
          title="El Visitante Nocturno" 
          excerpt="Cada noche, a las 3:33 AM exactamente, escucho tres golpes en mi ventana. Vivo en el séptimo piso."
          author="SombraEterna"
        />
        <CreepypastaCard 
          title="La Última Fotografía" 
          excerpt="Encontré una cámara desechable en el bosque. Al revelar las fotos, la última mostraba a alguien tomándome una foto a mí."
          author="FotógrafoMaldito"
        />
        <CreepypastaCard 
          title="Susurros en la Estática" 
          excerpt="Mi televisor se enciende solo a medianoche. Entre la estática, puedo ver caras y escuchar nombres. Ayer mencionaron el mío."
          author="Anónimo"
        />
        <CreepypastaCard 
          title="El Reflejo Equivocado" 
          excerpt="Mi reflejo en el espejo dejó de imitar mis movimientos. Ahora solo me observa y sonríe cuando yo no lo hago."
          author="EspejoRoto"
        />
      </div>
    </div>
  );
};

export default PopularCreepypastas;
