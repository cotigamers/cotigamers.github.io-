
import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { User, LogOut, Menu, X, CreditCard, MapPin, BookOpen, Home, CalendarDays } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/context/AuthContext';

const NavBar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const { user, signOut } = useAuth();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const closeMenu = () => setIsMenuOpen(false);

  const handleLogin = () => {
    navigate('/login');
    closeMenu();
  };

  const handleLogout = async () => {
    try {
      await signOut();
      toast({
        title: 'Sesión cerrada',
        description: 'Has abandonado el mundo de las sombras... por ahora.',
      });
      navigate('/');
    } catch (error) {
      toast({
        title: 'Error al cerrar sesión',
        description: 'No pudiste escapar...',
        variant: 'destructive',
      });
    }
    closeMenu();
  };

  const isActive = (path: string) => {
    return location.pathname === path ? 'text-horror-highlight' : 'text-foreground';
  };

  return (
    <nav className="bg-horror px-4 py-3 fixed w-full top-0 z-50 border-b border-horror-mist/20">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-horror-title text-foreground flex items-center gap-2">
          <span className="animate-pulse-slow">WhisperDark</span>
        </Link>
        
        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-6">
          {user && (
            <>
              <Link to="/feed" className={`${isActive('/feed')} hover:text-horror-highlight transition-colors`}>
                Feed
              </Link>
              <Link to="/creepypasta" className={`${isActive('/creepypasta')} hover:text-horror-highlight transition-colors`}>
                Creepypastas
              </Link>
              <Link to="/haunted-map" className={`${isActive('/haunted-map')} hover:text-horror-highlight transition-colors`}>
                Lugares Malditos
              </Link>
              <Link to="/challenges" className={`${isActive('/challenges')} hover:text-horror-highlight transition-colors`}>
                Desafíos
              </Link>
            </>
          )}
          
          <div className="flex items-center gap-3">
            {user ? (
              <>
                <Link to="/subscription">
                  <Button variant="outline" className="horror-button">
                    <CreditCard className="w-4 h-4 mr-2" />
                    VIP
                  </Button>
                </Link>
                <Button variant="outline" className="horror-button" onClick={handleLogout}>
                  <LogOut className="w-4 h-4 mr-2" />
                  Salir
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" className="horror-button" onClick={handleLogin}>
                  <User className="w-4 h-4 mr-2" />
                  Iniciar Sesión
                </Button>
                <Link to="/register">
                  <Button className="horror-button">
                    Registrarse
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
        
        {/* Mobile Menu Button */}
        <button className="md:hidden text-foreground" onClick={toggleMenu}>
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      
      {/* Mobile Menu */}
      <div className={cn(
        "absolute top-full left-0 w-full bg-horror transform transition-transform duration-300 border-b border-horror-mist/20 md:hidden",
        isMenuOpen ? "translate-y-0" : "-translate-y-full"
      )}>
        <div className="container mx-auto py-4 px-6 flex flex-col gap-4">
          {user && (
            <>
              <Link to="/feed" className={`flex items-center gap-2 ${isActive('/feed')} py-2 hover:text-horror-highlight transition-colors`} onClick={closeMenu}>
                <Home size={18} />
                Feed
              </Link>
              <Link to="/creepypasta" className={`flex items-center gap-2 ${isActive('/creepypasta')} py-2 hover:text-horror-highlight transition-colors`} onClick={closeMenu}>
                <BookOpen size={18} />
                Creepypastas
              </Link>
              <Link to="/haunted-map" className={`flex items-center gap-2 ${isActive('/haunted-map')} py-2 hover:text-horror-highlight transition-colors`} onClick={closeMenu}>
                <MapPin size={18} />
                Lugares Malditos
              </Link>
              <Link to="/challenges" className={`flex items-center gap-2 ${isActive('/challenges')} py-2 hover:text-horror-highlight transition-colors`} onClick={closeMenu}>
                <CalendarDays size={18} />
                Desafíos
              </Link>
              <div className="border-t border-horror-mist/20 my-2"></div>
            </>
          )}
          
          {user ? (
            <>
              <Link to="/subscription" className="flex items-center gap-2 text-foreground py-2 hover:text-horror-highlight transition-colors" onClick={closeMenu}>
                <CreditCard size={18} />
                Suscripción VIP
              </Link>
              <button className="flex items-center gap-2 text-foreground py-2 hover:text-horror-highlight transition-colors" onClick={handleLogout}>
                <LogOut size={18} />
                Cerrar Sesión
              </button>
            </>
          ) : (
            <>
              <button className="flex items-center gap-2 text-foreground py-2 hover:text-horror-highlight transition-colors" onClick={handleLogin}>
                <User size={18} />
                Iniciar Sesión
              </button>
              <Link to="/register" className="flex items-center gap-2 text-foreground py-2 hover:text-horror-highlight transition-colors" onClick={closeMenu}>
                Registrarse
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default NavBar;
