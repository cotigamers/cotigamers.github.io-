
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/ui/avatar";
import { 
  MessageCircle, Heart, Share2, Bookmark, Image, 
  Mic, Ghost, MapPin, User, AlertTriangle 
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface PostProps {
  author?: string;
  avatar?: string;
  content: string;
  image?: string;
  timestamp: string;
  comments: number;
  likes: number;
  isAnonymous?: boolean;
  location?: string;
}

const Post = ({
  author = "Usuario",
  avatar,
  content,
  image,
  timestamp,
  comments,
  likes,
  isAnonymous = false,
  location,
}: PostProps) => {
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [showAIAnalysis, setShowAIAnalysis] = useState(false);
  const [likeCount, setLikeCount] = useState(likes);
  const { toast } = useToast();

  const handleLike = () => {
    setLiked(!liked);
    setLikeCount(prev => liked ? prev - 1 : prev + 1);
  };

  const handleSave = () => {
    setSaved(!saved);
    toast({
      title: saved ? "Post removido de guardados" : "Post guardado",
      description: saved 
        ? "Has eliminado este post de tu colección" 
        : "Este post ha sido añadido a tu colección",
    });
  };

  const handleAnalyzeWithAI = () => {
    setShowAIAnalysis(true);
  };

  return (
    <div className="horror-card mb-6 overflow-hidden">
      {/* Cabecera del post */}
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center">
          {isAnonymous ? (
            <div className="bg-horror-dark w-10 h-10 rounded-full flex items-center justify-center text-horror-mist">
              <User size={20} />
            </div>
          ) : (
            <Avatar className="w-10 h-10 border border-horror-mist/30">
              <img src={avatar || "/placeholder.svg"} alt={author} />
            </Avatar>
          )}
          <div className="ml-3">
            <div className="font-medium text-foreground">
              {isAnonymous ? "Anónimo" : author}
            </div>
            <div className="text-xs text-horror-mist flex items-center">
              {timestamp}
              {location && (
                <>
                  <span className="mx-1">•</span>
                  <MapPin size={12} className="mr-1" />
                  {location}
                </>
              )}
            </div>
          </div>
        </div>
        {isAnonymous && (
          <div className="bg-horror-dark text-xs px-2 py-1 rounded-full text-horror-mist flex items-center">
            <Ghost size={12} className="mr-1" />
            Anónimo
          </div>
        )}
      </div>

      {/* Contenido del post */}
      <div className="mb-4">
        <p className="text-foreground whitespace-pre-line mb-4">{content}</p>
        {image && (
          <div className="rounded-lg overflow-hidden mb-2 relative">
            <img
              src={image}
              alt="Post image"
              className="w-full h-auto object-cover"
            />
          </div>
        )}
      </div>

      {/* Análisis de IA */}
      {showAIAnalysis && (
        <div className="mb-4 p-3 border border-horror-highlight/30 bg-horror-dark/50 rounded-lg animate-fade-in">
          <div className="text-sm text-horror-highlight font-horror-subtitle mb-2">
            Análisis de Actividad Paranormal
          </div>
          <p className="text-horror-mist text-sm">
            Detectamos anomalías en este post... ¿Ves esa sombra en la esquina superior derecha? 
            No parece ser algo natural. Ten cuidado si decides investigar más a fondo.
          </p>
        </div>
      )}

      {/* Acciones del post */}
      <div className="flex flex-col gap-3">
        <div className="flex justify-between border-t border-horror-mist/10 pt-3">
          <div className="flex gap-4">
            <Button
              variant="ghost"
              size="sm"
              className={cn(
                "text-horror-mist hover:text-foreground hover:bg-transparent p-0",
                liked && "text-horror-accent"
              )}
              onClick={handleLike}
            >
              <Heart size={20} className={cn("mr-1", liked && "fill-horror-accent")} />
              {likeCount}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-horror-mist hover:text-foreground hover:bg-transparent p-0"
            >
              <MessageCircle size={20} className="mr-1" />
              {comments}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-horror-mist hover:text-foreground hover:bg-transparent p-0"
            >
              <Share2 size={20} className="mr-1" />
              Compartir
            </Button>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className={cn(
              "text-horror-mist hover:text-foreground hover:bg-transparent p-0",
              saved && "text-horror-highlight"
            )}
            onClick={handleSave}
          >
            <Bookmark
              size={20}
              className={cn(saved && "fill-horror-highlight")}
            />
          </Button>
        </div>
        
        {!showAIAnalysis && (
          <div className="border-t border-horror-mist/10 pt-3">
            <div className="text-sm text-horror-mist mb-2">
              Parece que este post tiene actividad paranormal... ¿quieres que la IA intente analizarlo?
            </div>
            <div className="flex gap-2">
              <Button 
                size="sm" 
                className="horror-button" 
                onClick={handleAnalyzeWithAI}
              >
                Sí, analizar actividad
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="horror-button"
              >
                No, demasiado aterrador
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Herramientas de post */}
      <div className="border-t border-horror-mist/10 mt-4 pt-4 flex gap-2 overflow-x-auto pb-1">
        <Button variant="outline" size="sm" className="horror-button">
          <Image size={16} className="mr-1" />
          Subir imagen
        </Button>
        <Button variant="outline" size="sm" className="horror-button">
          <Mic size={16} className="mr-1" />
          Generar audio
        </Button>
        <Button variant="outline" size="sm" className="horror-button">
          <Ghost size={16} className="mr-1" />
          Susurros malditos
        </Button>
        <Button variant="outline" size="sm" className="horror-button">
          <MapPin size={16} className="mr-1" />
          Lugar maldito
        </Button>
        <Button variant="outline" size="sm" className="horror-button">
          <User size={16} className="mr-1" />
          Modo anónimo
        </Button>
      </div>
    </div>
  );
};

export default Post;
