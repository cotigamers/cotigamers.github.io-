
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Eye, Ghost, UserPlus, LogIn } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

const horrorInterests = [
  { id: 'paranormal', label: 'Paranormal experiences' },
  { id: 'creepypastas', label: 'Creepypastas' },
  { id: 'theories', label: 'Teorías perturbadoras' },
  { id: 'haunted', label: 'Haunted places' },
  { id: 'challenges', label: 'Retos de terror' },
];

const WelcomeScreen = () => {
  const [showInterests, setShowInterests] = useState(false);
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleInterestToggle = (id: string) => {
    setSelectedInterests(prev => 
      prev.includes(id) 
        ? prev.filter(item => item !== id) 
        : [...prev, id]
    );
  };

  const handleGuestLogin = () => {
    setShowInterests(true);
  };

  const handleSubmitInterests = () => {
    if (selectedInterests.length === 0) {
      toast.error("Por favor selecciona al menos un interés");
      return;
    }

    setLoading(true);
    
    // Simulating AI personalization delay
    setTimeout(() => {
      toast.success("¡Feed de horror personalizado para ti!");
      setLoading(false);
      navigate('/feed');
    }, 2000);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 relative">
      <div className="noise-bg"></div>
      
      {/* Logo/Title */}
      <h1 className="font-horror-title text-6xl md:text-7xl mb-4 text-white text-shadow-horror animate-pulse-slow">
        <span className="text-horror-accent">Whisper</span>Dark
      </h1>
      <p className="font-horror-subtitle text-horror-mist mb-12 text-center max-w-md">
        Donde los susurros cobran vida y tus pesadillas se vuelven realidad...
      </p>

      {!showInterests ? (
        <div className="space-y-4 w-full max-w-xs">
          <Button 
            className="horror-button w-full group"
            onClick={() => navigate('/login')}
          >
            <LogIn className="mr-2 h-4 w-4 group-hover:animate-pulse" />
            Iniciar Sesión
          </Button>
          
          <Button 
            className="horror-button w-full group"
            onClick={() => navigate('/register')}
          >
            <UserPlus className="mr-2 h-4 w-4 group-hover:animate-pulse" />
            Registrarse
          </Button>
          
          <Button 
            className="horror-button w-full group"
            variant="outline"
            onClick={handleGuestLogin}
          >
            <Eye className="mr-2 h-4 w-4 group-hover:animate-pulse" />
            Explorar como Invitado
          </Button>
        </div>
      ) : (
        <div className="horror-card max-w-md w-full animate-in fade-in duration-500">
          <h2 className="font-horror-subtitle text-xl text-center mb-6 text-horror-highlight animate-text-flicker">
            ¡Bienvenido a WhisperDark! Cuéntanos, ¿qué tipo de terror te interesa más?
          </h2>
          
          <div className="space-y-2 mb-6">
            {horrorInterests.map((interest) => (
              <button
                key={interest.id}
                onClick={() => handleInterestToggle(interest.id)}
                className={`flex items-center w-full p-3 rounded-md transition-all duration-300 ${
                  selectedInterests.includes(interest.id)
                    ? 'bg-horror-accent/40 border border-horror-accent/60'
                    : 'bg-horror-dark/60 border border-horror-mist/20 hover:bg-horror-dark/90'
                }`}
              >
                <Ghost className={`h-5 w-5 mr-3 ${
                  selectedInterests.includes(interest.id) ? 'text-white' : 'text-horror-mist'
                }`} />
                <span>{interest.label}</span>
                {selectedInterests.includes(interest.id) && (
                  <span className="ml-auto text-lg">✓</span>
                )}
              </button>
            ))}
          </div>
          
          <Button 
            className="horror-button w-full"
            onClick={handleSubmitInterests}
            disabled={loading}
          >
            {loading ? (
              <>
                <div className="animate-spin mr-2 h-4 w-4 border-2 border-current border-t-transparent rounded-full"></div>
                Personalizando tu feed de horror...
              </>
            ) : 'Continuar'}
          </Button>
        </div>
      )}

      <div className="absolute bottom-4 text-horror-mist/60 text-sm">
        Al continuar, aceptas que las entidades del más allá accedan a tu dispositivo
      </div>
    </div>
  );
};

export default WelcomeScreen;
