
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import NavBar from '@/components/NavBar';
import { signUp, supabase } from '@/integrations/supabase/client';

const Register = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username || !email || !password || !confirmPassword) {
      toast({
        title: 'Error de registro',
        description: 'Por favor completa todos los campos.',
        variant: 'destructive',
      });
      return;
    }
    
    if (password !== confirmPassword) {
      toast({
        title: 'Las contraseñas no coinciden',
        description: 'Por favor verifica que las contraseñas sean iguales.',
        variant: 'destructive',
      });
      return;
    }
    
    if (!acceptTerms) {
      toast({
        title: 'Términos y condiciones',
        description: 'Debes aceptar los términos y condiciones para continuar.',
        variant: 'destructive',
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Registrar usuario
      const { data, error } = await signUp(email, password, {
        username,
        full_name: username,
      });
      
      if (error) {
        throw error;
      }

      // Crear perfil de usuario
      if (data.user) {
        const { error: profileError } = await supabase
          .from('users_profiles')
          .insert([
            {
              id: data.user.id,
              username,
              fullname: username,
            }
          ]);
          
        if (profileError) {
          throw profileError;
        }
      }
      
      toast({
        title: 'Registro exitoso',
        description: 'Bienvenido a WhisperDark. El terror te espera...',
      });
      
      navigate('/feed');
    } catch (error: any) {
      toast({
        title: 'Error de registro',
        description: error.message || 'Ha ocurrido un error durante el registro.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-horror-gradient relative">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="noise-bg"></div>
      </div>
      
      <NavBar />
      
      <div className="container mx-auto px-4 pt-24 pb-10 flex justify-center items-center min-h-screen relative z-10">
        <div className="horror-card max-w-md w-full shadow-[0_0_25px_rgba(184,15,10,0.3)]">
          <h1 className="text-3xl font-horror-title text-foreground mb-6 text-center">
            Regístrate
          </h1>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Nombre de usuario</Label>
              <Input
                id="username"
                type="text"
                placeholder="Tu nombre en las sombras"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="horror-input"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="tu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="horror-input"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Contraseña</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="horror-input"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirmar Contraseña</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="horror-input"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="terms" 
                checked={acceptTerms}
                onCheckedChange={(checked) => setAcceptTerms(!!checked)}
                className="border-horror-mist data-[state=checked]:bg-horror-accent data-[state=checked]:border-horror-accent"
              />
              <label
                htmlFor="terms"
                className="text-sm text-horror-mist cursor-pointer"
              >
                Acepto los{' '}
                <Link to="/terms" className="text-horror-highlight hover:underline">
                  términos y condiciones
                </Link>
              </label>
            </div>
            
            <Button 
              type="submit" 
              className="w-full horror-button"
              disabled={isLoading}
            >
              {isLoading ? 'Registrando...' : 'Registrarse'}
            </Button>
          </form>
          
          <div className="mt-6 text-center">
            <p className="text-horror-mist">
              ¿Ya tienes una cuenta?{' '}
              <Link to="/login" className="text-horror-highlight hover:underline">
                Inicia sesión
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
