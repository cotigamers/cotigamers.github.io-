
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  MapPin, Search, Plus, Camera, Mic, 
  Ghost, Star, FileText, ArrowRight, Info 
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import NavBar from '@/components/NavBar';

const HauntedMap = () => {
  const [location, setLocation] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const { toast } = useToast();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!location.trim()) {
      toast({
        title: 'Ubicación requerida',
        description: 'Por favor ingresa una ubicación para buscar',
        variant: 'destructive',
      });
      return;
    }
    
    toast({
      title: 'Buscando ubicación',
      description: 'Explorando lugares malditos cercanos a ' + location,
    });
  };

  const handleAddLocation = () => {
    toast({
      title: 'Ubicación añadida',
      description: 'Tu lugar maldito ha sido agregado al mapa. Otros usuarios ahora pueden encontrarlo.',
    });
    setShowAddForm(false);
  };

  return (
    <div className="min-h-screen bg-horror-gradient relative">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="noise-bg"></div>
      </div>
      
      <NavBar />
      
      <div className="container mx-auto px-4 pt-24 pb-10 relative z-10">
        <h1 className="text-4xl font-horror-title text-foreground mb-2 text-center">
          Mapa de Lugares Malditos
        </h1>
        <p className="text-horror-mist text-xl text-center max-w-2xl mx-auto mb-10 font-horror-subtitle">
          Explora ubicaciones embrujadas y comparte tus propias experiencias paranormales
        </p>
        
        <div className="max-w-5xl mx-auto">
          {/* Buscador de ubicaciones */}
          <div className="horror-card mb-8">
            <div className="flex flex-col md:flex-row gap-4">
              <form onSubmit={handleSearch} className="flex-1 flex gap-2">
                <div className="relative flex-1">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-horror-mist" />
                  <Input
                    placeholder="Buscar ubicación..."
                    className="horror-input pl-10"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                  />
                </div>
                <Button type="submit" className="horror-button">
                  <Search className="w-5 h-5 mr-2" />
                  Buscar
                </Button>
              </form>
              
              <Button 
                variant="outline" 
                className="horror-button"
                onClick={() => setShowAddForm(!showAddForm)}
              >
                {showAddForm ? 'Cancelar' : (
                  <>
                    <Plus className="w-5 h-5 mr-2" />
                    Añadir lugar
                  </>
                )}
              </Button>
            </div>
            
            {/* Formulario para añadir ubicación */}
            {showAddForm && (
              <div className="mt-6 border-t border-horror-mist/20 pt-4 animate-fade-in">
                <h3 className="text-xl font-horror-subtitle mb-4">Reportar un nuevo lugar maldito</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-horror-mist mb-1">Nombre del lugar</label>
                    <Input className="horror-input" placeholder="Hospital Abandonado St. Martin" />
                  </div>
                  <div>
                    <label className="block text-horror-mist mb-1">Dirección exacta o coordenadas</label>
                    <Input className="horror-input" placeholder="Calle, Ciudad, Estado o Latitud, Longitud" />
                  </div>
                  <div>
                    <label className="block text-horror-mist mb-1">Describe tu experiencia paranormal</label>
                    <Textarea 
                      className="horror-input min-h-[100px]" 
                      placeholder="¿Qué viste o sentiste en este lugar? ¿Hay alguna historia o leyenda local?"
                    />
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Button variant="outline" className="horror-button">
                      <Camera className="w-4 h-4 mr-2" />
                      Subir foto
                    </Button>
                    <Button variant="outline" className="horror-button">
                      <Mic className="w-4 h-4 mr-2" />
                      Subir audio
                    </Button>
                    <Button onClick={handleAddLocation} className="horror-button sm:ml-auto">
                      Añadir al mapa
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* Mapa y ubicaciones */}
          <div className="grid md:grid-cols-3 gap-6">
            {/* Placeholder del mapa */}
            <div className="md:col-span-2 horror-card min-h-[400px] flex items-center justify-center">
              <div className="text-center">
                <MapPin className="w-16 h-16 mx-auto mb-4 text-horror-accent animate-pulse" />
                <p className="text-horror-mist">Mapa de lugares malditos</p>
                <p className="text-sm text-horror-mist/70 mt-2">
                  Selecciona un lugar en el mapa o busca por ubicación
                </p>
              </div>
            </div>
            
            {/* Lugares cercanos */}
            <div>
              <div className="horror-card mb-6">
                <h3 className="text-xl font-horror-subtitle mb-4 flex items-center">
                  <MapPin className="w-5 h-5 mr-2 text-horror-accent" />
                  Lugares Cercanos
                </h3>
                <div className="space-y-4">
                  <HauntedLocation 
                    name="Mansión Valdemar" 
                    distance="2.3 km" 
                    rating={4.8}
                  />
                  <HauntedLocation 
                    name="Cementerio Olvidado" 
                    distance="3.7 km" 
                    rating={4.5}
                  />
                  <HauntedLocation 
                    name="Hospital Abandonado" 
                    distance="5.1 km" 
                    rating={4.9}
                  />
                  <HauntedLocation 
                    name="Túnel del Ferrocarril" 
                    distance="7.8 km" 
                    rating={4.2}
                  />
                </div>
              </div>
              
              <div className="horror-card">
                <h3 className="text-xl font-horror-subtitle mb-4 flex items-center">
                  <Info className="w-5 h-5 mr-2 text-horror-accent" />
                  Consejos de Seguridad
                </h3>
                <ul className="text-horror-mist space-y-2 text-sm">
                  <li className="flex gap-2">
                    <ArrowRight className="w-4 h-4 text-horror-accent flex-shrink-0 mt-0.5" />
                    <span>Nunca visites lugares abandonados solo.</span>
                  </li>
                  <li className="flex gap-2">
                    <ArrowRight className="w-4 h-4 text-horror-accent flex-shrink-0 mt-0.5" />
                    <span>Respeta las señales de prohibición y propiedad privada.</span>
                  </li>
                  <li className="flex gap-2">
                    <ArrowRight className="w-4 h-4 text-horror-accent flex-shrink-0 mt-0.5" />
                    <span>Lleva siempre un teléfono móvil con batería completa.</span>
                  </li>
                  <li className="flex gap-2">
                    <ArrowRight className="w-4 h-4 text-horror-accent flex-shrink-0 mt-0.5" />
                    <span>Informa a alguien sobre tu ubicación y hora estimada de regreso.</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          
          {/* Testimonios destacados */}
          <div className="mt-10">
            <h2 className="text-2xl font-horror-subtitle mb-6 text-center">
              Experiencias Destacadas
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <TestimonialCard 
                location="Mansión Valdemar" 
                author="Carlos Espectro"
                content="Escuché claramente risas de niños en el tercer piso, aunque estaba vacío. Las grabaciones que hice capturaron voces que decían 'ayúdanos a salir'."
              />
              <TestimonialCard 
                location="Hospital Abandonado" 
                author="Laura Tenebrosa"
                content="En la antigua sala de cirugía, la temperatura bajó 10 grados de repente. Mi cámara captó una niebla con forma humana que parecía seguirme."
              />
            </div>
            <div className="text-center mt-6">
              <Button className="horror-button">
                <Ghost className="w-5 h-5 mr-2" />
                Ver más experiencias
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Componentes de utilidad
const HauntedLocation = ({ 
  name, 
  distance, 
  rating 
}: { 
  name: string, 
  distance: string,
  rating: number
}) => (
  <div className="flex justify-between items-center p-3 bg-horror-dark/50 rounded-lg border border-horror-mist/20">
    <div>
      <div className="font-medium text-foreground">{name}</div>
      <div className="text-xs text-horror-mist">a {distance}</div>
    </div>
    <div className="flex items-center">
      <div className="text-sm text-horror-mist mr-1">{rating}</div>
      <Star className="w-4 h-4 fill-horror-accent text-horror-accent" />
    </div>
  </div>
);

const TestimonialCard = ({ 
  location, 
  author, 
  content 
}: { 
  location: string, 
  author: string, 
  content: string 
}) => (
  <div className="horror-card">
    <div className="flex justify-between items-start mb-3">
      <h3 className="font-horror-subtitle text-lg">
        <MapPin className="w-4 h-4 inline-block mr-1 text-horror-accent" />
        {location}
      </h3>
      <div className="flex items-center gap-1">
        <FileText className="w-4 h-4 text-horror-mist" />
        <span className="text-xs text-horror-mist">Testimonio</span>
      </div>
    </div>
    <p className="text-horror-mist mb-4">{content}</p>
    <div className="flex justify-between items-center">
      <span className="text-sm text-horror-mist">Por: {author}</span>
      <Button variant="outline" size="sm" className="horror-button">
        Leer más
      </Button>
    </div>
  </div>
);

export default HauntedMap;
