
import React, { useState } from 'react';
import { Check, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import NavBar from '@/components/NavBar';

const Subscription = () => {
  const [selectedPlan, setSelectedPlan] = useState('monthly');
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleSubscribe = () => {
    setIsProcessing(true);
    
    // Simulación de procesamiento de pago
    setTimeout(() => {
      setIsProcessing(false);
      toast({
        title: 'Suscripción activada',
        description: 'Ahora eres parte de WhisperDark VIP. El verdadero terror comienza ahora...',
      });
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-horror-gradient relative">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="noise-bg"></div>
      </div>
      
      <NavBar />
      
      <div className="container mx-auto px-4 pt-24 pb-10 relative z-10">
        <h1 className="text-4xl font-horror-title text-foreground mb-6 text-center">
          WhisperDark VIP
        </h1>
        <p className="text-horror-mist text-xl text-center max-w-2xl mx-auto mb-12 font-horror-subtitle">
          Desbloquea las experiencias más aterradoras y exclusivas
        </p>
        
        <div className="max-w-3xl mx-auto">
          <RadioGroup 
            value={selectedPlan} 
            onValueChange={setSelectedPlan}
            className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12"
          >
            {/* Plan Mensual */}
            <div className="relative">
              <RadioGroupItem 
                value="monthly" 
                id="monthly" 
                className="absolute top-4 right-4 border-horror-mist data-[state=checked]:bg-horror-accent data-[state=checked]:border-horror-accent"
              />
              <label 
                htmlFor="monthly" 
                className={`horror-card block h-full cursor-pointer p-6 ${
                  selectedPlan === 'monthly' ? 'ring-2 ring-horror-accent' : ''
                }`}
              >
                <div className="font-horror-subtitle text-2xl mb-2">Membresía Mensual</div>
                <div className="text-3xl font-bold mb-4">4,99 €<span className="text-base font-normal text-horror-mist"> /mes</span></div>
                <ul className="space-y-2 mb-6">
                  <FeatureItem text="Filtros exclusivos para fotos de terror" />
                  <FeatureItem text="Voces de IA premium para historias narradas" />
                  <FeatureItem text="Sin anuncios" />
                  <FeatureItem text="Modo Pesadilla interactivo avanzado" />
                  <FeatureItem text="Insignia VIP del Más Allá" />
                </ul>
              </label>
            </div>
            
            {/* Plan Anual */}
            <div className="relative">
              <RadioGroupItem 
                value="annual" 
                id="annual" 
                className="absolute top-4 right-4 border-horror-mist data-[state=checked]:bg-horror-accent data-[state=checked]:border-horror-accent"
              />
              <label 
                htmlFor="annual" 
                className={`horror-card block h-full cursor-pointer p-6 ${
                  selectedPlan === 'annual' ? 'ring-2 ring-horror-accent' : ''
                }`}
              >
                <div className="font-horror-subtitle text-2xl mb-2">Membresía Anual</div>
                <div className="text-3xl font-bold mb-4">49,99 €<span className="text-base font-normal text-horror-mist"> /año</span></div>
                <div className="bg-horror-accent/20 text-foreground rounded-full px-3 py-1 text-sm inline-block mb-4">
                  2 meses gratis
                </div>
                <ul className="space-y-2 mb-6">
                  <FeatureItem text="Todo lo de la membresía mensual" />
                  <FeatureItem text="Acceso anticipado a retos y eventos especiales" />
                  <FeatureItem text="Creepypastas exclusivas generadas por IA" />
                  <FeatureItem text="500 DarkCoins de regalo" />
                </ul>
              </label>
            </div>
          </RadioGroup>
          
          {/* Paquetes de DarkCoins */}
          <div className="horror-card mb-10">
            <h2 className="text-2xl font-horror-subtitle mb-4">Paquetes de DarkCoins 💀</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <CoinPackage amount="200" price="1,99 €" />
              <CoinPackage amount="600" price="4,99 €" />
              <CoinPackage amount="1500" price="9,99 €" />
              <CoinPackage amount="4000" price="19,99 €" />
            </div>
          </div>
          
          <div className="text-center">
            <Button 
              onClick={handleSubscribe} 
              className="horror-button text-lg py-6 px-10"
              disabled={isProcessing}
            >
              <CreditCard className="w-5 h-5 mr-2" />
              {isProcessing ? 'Procesando...' : `Hazte VIP del Más Allá 👁️`}
            </Button>
            <p className="text-horror-mist text-sm mt-4">
              Puedes cancelar tu suscripción en cualquier momento. No hay reembolsos por periodos parciales.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Componentes de utilidad
const FeatureItem = ({ text }: { text: string }) => (
  <li className="flex items-start">
    <Check className="w-5 h-5 text-horror-accent mr-2 flex-shrink-0" />
    <span className="text-foreground">{text}</span>
  </li>
);

const CoinPackage = ({ amount, price }: { amount: string, price: string }) => (
  <div className="bg-horror-dark border border-horror-mist/20 rounded-lg p-4 hover:border-horror-highlight/50 transition-colors cursor-pointer">
    <div className="text-xl font-bold mb-1">{amount} DarkCoins</div>
    <div className="text-horror-mist">{price}</div>
    <Button variant="outline" className="w-full mt-2 horror-button">
      Comprar
    </Button>
  </div>
);

export default Subscription;
