
import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Home, ArrowLeft } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: Usuario intentó acceder a una ruta inexistente:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-horror-gradient px-4">
      <div className="horror-card text-center max-w-md w-full">
        <div className="animate-pulse-slow text-6xl font-horror-title mb-4">404</div>
        
        <h1 className="text-2xl font-horror-subtitle mb-6">Página no encontrada</h1>
        
        <p className="text-horror-mist mb-8">
          Parece que te has adentrado demasiado en la oscuridad y te has perdido en el camino...
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            variant="outline" 
            className="horror-button flex items-center gap-2"
            onClick={() => window.history.back()}
          >
            <ArrowLeft size={16} />
            Volver atrás
          </Button>
          
          <Link to="/">
            <Button className="horror-button w-full sm:w-auto flex items-center gap-2">
              <Home size={16} />
              Ir al inicio
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
