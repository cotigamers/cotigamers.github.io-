
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';

const Index = () => {
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [showInterests, setShowInterests] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const interests = [
    { id: 'paranormal', label: 'Experiencias Paranormales' },
    { id: 'creepypastas', label: 'Creepypastas' },
    { id: 'theories', label: 'Teorías Perturbadoras' },
    { id: 'haunted', label: 'Lugares Embrujados' },
    { id: 'challenges', label: 'Retos de Terror' },
  ];

  const handleInterestChange = (id: string, checked: boolean) => {
    if (checked) {
      setSelectedInterests([...selectedInterests, id]);
    } else {
      setSelectedInterests(selectedInterests.filter(item => item !== id));
    }
  };

  const handleLogin = () => {
    navigate('/login');
  };

  const handleRegister = () => {
    navigate('/register');
  };

  const handleGuestExplore = () => {
    setShowInterests(true);
  };

  const handleSubmitInterests = () => {
    if (selectedInterests.length === 0) {
      toast({
        title: "Selección requerida",
        description: "Por favor selecciona al menos un interés para personalizar tu experiencia.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Personalizando tu feed de horror...",
      description: "Preparando tu experiencia basada en tus intereses oscuros...",
    });
    
    // Aquí podrías almacenar estos intereses en localStorage o en un estado global
    setTimeout(() => {
      navigate('/feed');
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-horror-gradient relative px-4 pt-16">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="noise-bg"></div>
      </div>
      
      <div className="relative z-10 max-w-md w-full">
        <div className="mb-10 text-center">
          <h1 className="text-5xl font-horror-title text-foreground mb-4 animate-text-flicker">
            WhisperDark
          </h1>
          <p className="text-xl text-horror-mist font-horror-subtitle">
            Donde los susurros cobran vida...
          </p>
        </div>

        {!showInterests ? (
          <div className="horror-card flex flex-col gap-4 shadow-[0_0_25px_rgba(184,15,10,0.3)]">
            <Button 
              className="horror-button text-lg py-6"
              onClick={handleLogin}
            >
              Iniciar Sesión
            </Button>
            
            <Button 
              className="horror-button text-lg py-6"
              onClick={handleRegister}
            >
              Registrarse
            </Button>
            
            <Button 
              variant="outline" 
              className="horror-button text-lg py-6"
              onClick={handleGuestExplore}
            >
              Explorar como Invitado
            </Button>
          </div>
        ) : (
          <div className="horror-card flex flex-col gap-4 shadow-[0_0_25px_rgba(184,15,10,0.3)]">
            <h2 className="text-xl font-horror-subtitle text-foreground mb-2">
              ¡Bienvenido a WhisperDark!
            </h2>
            <p className="text-horror-mist mb-4">
              Cuéntanos, ¿qué tipo de terror te interesa más? (Selecciona uno o más)
            </p>
            
            <div className="space-y-3">
              {interests.map((interest) => (
                <div key={interest.id} className="flex items-center space-x-3">
                  <Checkbox 
                    id={interest.id} 
                    checked={selectedInterests.includes(interest.id)}
                    onCheckedChange={(checked) => handleInterestChange(interest.id, checked as boolean)}
                    className="border-horror-mist data-[state=checked]:bg-horror-accent data-[state=checked]:border-horror-accent"
                  />
                  <label 
                    htmlFor={interest.id}
                    className="text-foreground cursor-pointer"
                  >
                    {interest.label}
                  </label>
                </div>
              ))}
            </div>
            
            <Button 
              className="horror-button text-lg py-6 mt-4"
              onClick={handleSubmitInterests}
            >
              Continuar
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Index;
