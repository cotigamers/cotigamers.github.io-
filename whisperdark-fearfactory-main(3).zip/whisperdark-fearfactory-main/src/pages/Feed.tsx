
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar } from '@/components/ui/avatar';
import { Image, Mic, Ghost, MapPin, User, Bell } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import NavBar from '@/components/NavBar';
import Post from '@/components/Post';

const Feed = () => {
  const [postContent, setPostContent] = useState('');
  const { toast } = useToast();

  const handlePost = () => {
    if (!postContent.trim()) {
      toast({
        title: 'Post vacío',
        description: 'Por favor escribe algo para publicar',
        variant: 'destructive',
      });
      return;
    }
    
    toast({
      title: 'Post publicado',
      description: 'Tu historia de terror ha sido compartida con el mundo.',
    });
    
    setPostContent('');
  };

  return (
    <div className="min-h-screen bg-horror-gradient relative">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="noise-bg"></div>
      </div>
      
      <NavBar />
      
      <div className="container mx-auto px-4 pt-24 pb-10 relative z-10">
        <h1 className="text-4xl font-horror-title text-foreground mb-6 text-center md:text-left">
          Tu Feed de Terror
        </h1>
        
        <div className="flex flex-col lg:flex-row gap-6 max-w-6xl mx-auto">
          <div className="lg:w-2/3">
            {/* Publicar nuevo post */}
            <div className="horror-card mb-6">
              <div className="flex items-start gap-4 mb-4">
                <Avatar className="w-10 h-10 border border-horror-mist/30">
                  <img src="/placeholder.svg" alt="Tu perfil" />
                </Avatar>
                <Textarea
                  placeholder="Comparte tu experiencia paranormal..."
                  className="horror-input resize-none flex-1 min-h-[100px]"
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                />
              </div>
              
              <div className="flex flex-col sm:flex-row gap-2 justify-between">
                <div className="flex gap-2 overflow-x-auto pb-1">
                  <Button variant="outline" size="sm" className="horror-button flex-shrink-0">
                    <Image size={16} className="mr-1" />
                    Imagen
                  </Button>
                  <Button variant="outline" size="sm" className="horror-button flex-shrink-0">
                    <Mic size={16} className="mr-1" />
                    Audio
                  </Button>
                  <Button variant="outline" size="sm" className="horror-button flex-shrink-0">
                    <Ghost size={16} className="mr-1" />
                    IA
                  </Button>
                  <Button variant="outline" size="sm" className="horror-button flex-shrink-0">
                    <MapPin size={16} className="mr-1" />
                    Ubicación
                  </Button>
                  <Button variant="outline" size="sm" className="horror-button flex-shrink-0">
                    <User size={16} className="mr-1" />
                    Anónimo
                  </Button>
                </div>
                
                <Button onClick={handlePost} className="horror-button sm:ml-auto mt-2 sm:mt-0">
                  Publicar
                </Button>
              </div>
            </div>
            
            {/* Feed de posts */}
            <Post
              author="María Sombría"
              content="Anoche escuché pasos en mi ático, pero vivo solo y la escalera chirría cuando alguien sube. Lo más extraño es que esta mañana encontré todas las fotos familiares boca abajo. ¿Alguien ha experimentado algo similar?"
              timestamp="Hace 2 horas"
              comments={23}
              likes={45}
            />
            
            <Post
              author="Carlos Espectro"
              content="Esta foto la tomé en el Sanatorio Abandonado de Sierra Negra. Cuando la revisé en casa, noté una figura en la ventana del tercer piso. El sanatorio solo tiene dos pisos según los planos oficiales..."
              image="/placeholder.svg"
              timestamp="Hace 5 horas"
              comments={56}
              likes={122}
              location="Sanatorio Sierra Negra"
            />
            
            <Post
              content="He estado recibiendo llamadas del número de mi abuela. Ella falleció hace 3 meses. Nadie ha tocado su teléfono que sigue en su casa cerrada. Las llamadas son solo estática y susurros."
              timestamp="Ayer"
              comments={42}
              likes={87}
              isAnonymous={true}
            />
          </div>
          
          <div className="lg:w-1/3">
            {/* Desafío diario */}
            <div className="horror-card mb-6">
              <h3 className="text-xl font-horror-subtitle mb-3 flex items-center">
                <Bell className="w-5 h-5 mr-2 text-horror-accent" />
                Desafío del día
              </h3>
              <p className="text-horror-mist mb-4">
                Toma una foto de un espejo en la oscuridad y súbela aquí. ¿Te atreves a mirar lo que pueda aparecer en el reflejo?
              </p>
              <Button className="w-full horror-button">
                Aceptar desafío
              </Button>
            </div>
            
            {/* Mensajes del Más Allá */}
            <div className="horror-card mb-6">
              <h3 className="text-xl font-horror-subtitle mb-3">
                Mensajes del Más Allá
              </h3>
              <div className="space-y-3">
                <div className="p-3 bg-horror-dark/50 rounded-lg border border-horror-mist/20">
                  <p className="text-foreground italic font-horror-subtitle">
                    "No estás solo... mira detrás de ti 👁️"
                  </p>
                </div>
                <div className="p-3 bg-horror-dark/50 rounded-lg border border-horror-mist/20">
                  <p className="text-foreground italic font-horror-subtitle">
                    "Ese lugar del que hablas... ya no debería existir"
                  </p>
                </div>
                <div className="p-3 bg-horror-dark/50 rounded-lg border border-horror-mist/20">
                  <p className="text-foreground italic font-horror-subtitle">
                    "Yo vi lo mismo, pero no sobreviví para contarlo"
                  </p>
                </div>
              </div>
              <Button variant="outline" className="w-full mt-4 horror-button">
                <Ghost className="w-4 h-4 mr-2" />
                Generar otro mensaje
              </Button>
            </div>
            
            {/* Tendencias de terror */}
            <div className="horror-card">
              <h3 className="text-xl font-horror-subtitle mb-3">
                Tendencias de Terror
              </h3>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-horror-accent font-bold">#1</span>
                  <span className="text-foreground">#RitualDeLaMedianoche</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-horror-accent font-bold">#2</span>
                  <span className="text-foreground">#HospitalAbandonado</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-horror-accent font-bold">#3</span>
                  <span className="text-foreground">#SusurrosNocturnos</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-horror-accent font-bold">#4</span>
                  <span className="text-foreground">#FiguraEnLaVentana</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-horror-accent font-bold">#5</span>
                  <span className="text-foreground">#SueñosParalelos</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Feed;
