
import React, { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import NavBar from '@/components/NavBar';
import { generateStoryWithAI } from '@/services/iaService';
import { supabase } from '@/integrations/supabase/client';
import StoryEditor from '@/components/creepypasta/StoryEditor';
import StoryDisplay from '@/components/creepypasta/StoryDisplay';
import PopularCreepypastas from '@/components/creepypasta/PopularCreepypastas';

const Creepypasta = () => {
  const [storyStart, setStoryStart] = useState('');
  const [generatedStory, setGeneratedStory] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [title, setTitle] = useState('');
  const { toast } = useToast();

  const handleGenerateStory = async () => {
    if (storyStart.length < 10) {
      toast({
        title: 'Historia muy corta',
        description: 'Por favor escribe al menos dos frases para comenzar tu historia.',
        variant: 'destructive',
      });
      return;
    }
    
    setIsGenerating(true);
    
    try {
      // Intentar generar una historia con IA
      const generatedContent = await generateStoryWithAI(storyStart);
      setGeneratedStory(generatedContent);
      
      toast({
        title: 'Historia generada',
        description: 'Tu creepypasta ha sido creada con éxito.',
      });
    } catch (error) {
      console.error('Error al generar historia:', error);
      
      // Fallback en caso de error con la IA
      const storyExtension = `${storyStart}\n\nCuando abrí la puerta del sótano, la oscuridad parecía respirar. Un frío inusual subió por mis piernas. Bajé los escalones lentamente, sosteniendo la linterna con mano temblorosa. \n\nAl llegar al último escalón, la luz reveló algo imposible: huellas húmedas que iban desde el centro de la habitación hasta la pared. No había puertas adicionales ni ventanas. Las huellas simplemente... terminaban en el muro sólido.\n\nMe acerqué para examinarlas mejor. Eran pequeñas, como de un niño, pero deformadas de alguna manera. Al tocar una, mi dedo se manchó con un líquido negro y espeso. No era agua.\n\nEntonces escuché una respiración detrás de mí. Me giré rápidamente, pero la linterna se apagó en ese preciso instante. En la completa oscuridad, sentí un aliento frío en mi nuca y una voz infantil susurró:\n\n"Te estaba esperando."`;
      
      setGeneratedStory(storyExtension);
      
      toast({
        title: 'Historia generada',
        description: 'Se ha utilizado el modo offline para generar tu historia.',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveStory = async () => {
    if (!title) {
      toast({
        title: 'Título requerido',
        description: 'Por favor añade un título a tu historia antes de guardarla.',
        variant: 'destructive',
      });
      return;
    }

    if (!generatedStory) {
      toast({
        title: 'No hay historia para guardar',
        description: 'Por favor genera una historia primero.',
        variant: 'destructive',
      });
      return;
    }

    try {
      const { data: userData, error: userError } = await supabase.auth.getUser();
      
      if (userError || !userData.user) {
        toast({
          title: 'No has iniciado sesión',
          description: 'Debes iniciar sesión para guardar tu historia.',
          variant: 'destructive',
        });
        return;
      }

      const { error } = await supabase.from('creepypastas').insert([
        {
          user_id: userData.user.id,
          title: title,
          content: generatedStory,
          is_anonymous: false
        }
      ]);

      if (error) {
        throw error;
      }

      toast({
        title: 'Historia guardada',
        description: 'Tu creepypasta ha sido guardada con éxito.',
      });
    } catch (error: any) {
      toast({
        title: 'Error al guardar',
        description: error.message || 'Ha ocurrido un error al guardar tu historia.',
        variant: 'destructive',
      });
    }
  };

  const handleNarrateStory = () => {
    toast({
      title: 'Narración iniciada',
      description: 'Escucha atentamente... la voz del más allá está narrando tu historia.',
    });
  };

  const handleEditStory = () => {
    setStoryStart(generatedStory || '');
    setGeneratedStory(null);
  };

  return (
    <div className="min-h-screen bg-horror-gradient relative">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="noise-bg"></div>
      </div>
      
      <NavBar />
      
      <div className="container mx-auto px-4 pt-24 pb-10 relative z-10">
        <h1 className="text-4xl font-horror-title text-foreground mb-2 text-center">
          Creepypasta AI
        </h1>
        <p className="text-horror-mist text-xl text-center max-w-2xl mx-auto mb-10 font-horror-subtitle">
          Escribe el inicio de tu historia y la IA la completará con un giro macabro...
        </p>
        
        <div className="max-w-3xl mx-auto">
          {!generatedStory ? (
            <StoryEditor 
              storyStart={storyStart}
              setStoryStart={setStoryStart}
              handleGenerateStory={handleGenerateStory}
              isGenerating={isGenerating}
            />
          ) : (
            <StoryDisplay 
              title={title}
              setTitle={setTitle}
              generatedStory={generatedStory}
              handleSaveStory={handleSaveStory}
              handleNarrateStory={handleNarrateStory}
              handleEditStory={handleEditStory}
              handleCreateNewStory={() => setGeneratedStory(null)}
            />
          )}
          
          <PopularCreepypastas />
        </div>
      </div>
    </div>
  );
};

export default Creepypasta;
