
import React, { useState } from 'react';
import { Camera, Award, Gift, Clock, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import NavBar from '@/components/NavBar';

const Challenges = () => {
  const [currentChallenge, setCurrentChallenge] = useState<null | string>(null);
  const { toast } = useToast();

  const handleAcceptChallenge = (challenge: string) => {
    setCurrentChallenge(challenge);
    toast({
      title: "Desafío aceptado",
      description: "¿Serás capaz de completarlo? El tiempo corre...",
    });
  };

  const handleSkipChallenge = () => {
    toast({
      title: "Desafío cambiado",
      description: "Se te ha asignado un nuevo desafío de terror...",
    });
  };

  return (
    <div className="min-h-screen bg-horror-gradient relative">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="noise-bg"></div>
      </div>
      
      <NavBar />
      
      <div className="container mx-auto px-4 pt-24 pb-10 relative z-10">
        <h1 className="text-4xl font-horror-title text-foreground mb-2 text-center">
          Desafíos de Terror
        </h1>
        <p className="text-horror-mist text-xl text-center max-w-2xl mx-auto mb-12 font-horror-subtitle">
          ¿Te atreves a completar estos retos para ganar recompensas exclusivas?
        </p>
        
        <div className="max-w-3xl mx-auto">
          {/* Desafío diario */}
          <div className="horror-card mb-8">
            <div className="flex flex-col md:flex-row justify-between items-start gap-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-5 h-5 text-horror-accent" />
                  <span className="text-horror-mist text-sm">Desafío del día</span>
                </div>
                <h2 className="text-2xl font-horror-subtitle mb-3">
                  Foto en el espejo
                </h2>
                <p className="text-horror-mist mb-4">
                  Toma una foto de un espejo en la oscuridad y súbela aquí. ¿Te atreves a mirar lo que pueda aparecer en el reflejo?
                </p>
                <div className="flex flex-wrap gap-2 mb-6">
                  <span className="bg-horror-dark text-horror-mist text-xs px-3 py-1 rounded-full">
                    +50 puntos
                  </span>
                  <span className="bg-horror-dark text-horror-mist text-xs px-3 py-1 rounded-full">
                    Insignia "Valiente"
                  </span>
                </div>
              </div>
              
              <div className="flex flex-col gap-3 w-full md:w-auto">
                {currentChallenge === 'mirror' ? (
                  <Button className="horror-button">
                    <Camera className="w-5 h-5 mr-2" />
                    Subir evidencia
                  </Button>
                ) : (
                  <>
                    <Button 
                      className="horror-button"
                      onClick={() => handleAcceptChallenge('mirror')}
                    >
                      Aceptar desafío
                    </Button>
                    <Button 
                      variant="outline" 
                      className="horror-button"
                      onClick={handleSkipChallenge}
                    >
                      Otro reto, por favor
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>
          
          {/* Progreso del usuario */}
          <div className="horror-card mb-8">
            <h3 className="text-xl font-horror-subtitle mb-4">Tu progreso</h3>
            <div className="mb-6">
              <div className="flex justify-between mb-2">
                <span className="text-foreground">Nivel de terror</span>
                <span className="text-horror-accent">Nivel 3</span>
              </div>
              <Progress value={65} className="h-2 bg-horror-dark" />
            </div>
            
            <div className="flex justify-between text-horror-mist text-sm mb-6">
              <span>125 puntos más para el siguiente nivel</span>
              <span>Total: 175 puntos</span>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <InsigniaItem name="Intrépido" acquired={true} />
              <InsigniaItem name="Cazafantasmas" acquired={true} />
              <InsigniaItem name="Valiente" acquired={false} />
              <InsigniaItem name="Medium" acquired={false} />
              <InsigniaItem name="Leyenda" acquired={false} />
              <InsigniaItem name="Terror Máximo" acquired={false} />
            </div>
          </div>
          
          {/* Desafíos semanales */}
          <div className="horror-card">
            <h3 className="text-xl font-horror-subtitle mb-4 flex items-center">
              <Award className="w-5 h-5 mr-2 text-horror-accent" />
              Desafíos semanales
            </h3>
            
            <div className="space-y-6">
              <WeeklyChallenge 
                title="Narración escalofriante" 
                description="Graba un audio narrando una experiencia paranormal y compártela" 
                points={100}
                completed={false}
              />
              <WeeklyChallenge 
                title="Fotografía nocturna" 
                description="Toma una foto de un cementerio o lugar abandonado durante la noche" 
                points={150}
                completed={true}
              />
              <WeeklyChallenge 
                title="Ritual de invocación" 
                description="Realiza el ritual de la Dama de la Vela y documenta tu experiencia" 
                points={200}
                completed={false}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Componentes de utilidad
const InsigniaItem = ({ name, acquired }: { name: string, acquired: boolean }) => (
  <div 
    className={`text-center p-3 rounded-lg border ${
      acquired 
        ? 'border-horror-accent/50 bg-horror-accent/10' 
        : 'border-horror-mist/20 bg-horror-dark/30 opacity-60'
    }`}
  >
    <Award className={`w-8 h-8 mx-auto mb-2 ${acquired ? 'text-horror-accent' : 'text-horror-mist/50'}`} />
    <div className={acquired ? 'text-foreground' : 'text-horror-mist/70'}>
      {name}
    </div>
  </div>
);

const WeeklyChallenge = ({ 
  title, 
  description, 
  points, 
  completed 
}: { 
  title: string, 
  description: string, 
  points: number,
  completed: boolean
}) => (
  <div className="flex items-start gap-4 p-4 border-b border-horror-mist/10 last:border-0">
    <div className={`rounded-full p-1 ${completed ? 'text-horror-accent' : 'text-horror-mist/50'}`}>
      {completed ? (
        <CheckCircle2 className="w-6 h-6" />
      ) : (
        <Gift className="w-6 h-6" />
      )}
    </div>
    <div className="flex-1">
      <h4 className="text-lg font-medium mb-1">{title}</h4>
      <p className="text-horror-mist text-sm mb-2">{description}</p>
      <div className="flex justify-between items-center">
        <span className="text-xs bg-horror-dark text-horror-mist px-2 py-1 rounded-full">
          +{points} puntos
        </span>
        {!completed && (
          <Button variant="outline" size="sm" className="horror-button text-xs">
            Iniciar <ArrowRight className="w-3 h-3 ml-1" />
          </Button>
        )}
      </div>
    </div>
  </div>
);

export default Challenges;
