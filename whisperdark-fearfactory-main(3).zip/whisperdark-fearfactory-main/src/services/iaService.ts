
import { supabase } from '@/integrations/supabase/client';

export const generateStoryWithAI = async (prompt: string): Promise<string> => {
  try {
    const { data, error } = await supabase.functions.invoke('generate-horror-story', {
      body: { prompt },
    });
    
    if (error) {
      console.error('Error al generar historia:', error);
      throw new Error(error.message);
    }
    
    return data.story;
  } catch (error) {
    console.error('Error en el servicio de generación de historias:', error);
    throw error;
  }
};

export const analyzeImageWithAI = async (imageUrl: string): Promise<string> => {
  try {
    const { data, error } = await supabase.functions.invoke('analyze-paranormal-image', {
      body: { imageUrl },
    });
    
    if (error) {
      console.error('Error al analizar imagen:', error);
      throw new Error(error.message);
    }
    
    return data.analysis;
  } catch (error) {
    console.error('Error en el servicio de análisis de imágenes:', error);
    throw error;
  }
};
