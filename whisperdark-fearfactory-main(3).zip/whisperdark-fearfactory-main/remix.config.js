
/** @type {import('@remix-run/dev').AppConfig} */
module.exports = {
  appDirectory: "src",
  ignoredRouteFiles: ["**/.*"],
  assetsBuildDirectory: "dist/assets",
  publicPath: "/assets/",
  serverBuildPath: "dist/index.js",
  serverModuleFormat: "cjs",
  routes(defineRoutes) {
    return defineRoutes((route) => {
      // Define your routes here if you want to use the Remix file-based routing
      // This is optional and you can continue using React Router as is
    });
  },
};
