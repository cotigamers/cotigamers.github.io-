
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { imageUrl } = await req.json();

    // Funcionalidad simulada: en producción, conectaríamos con un servicio de IA para analizar imágenes
    console.log('Analizando imagen:', imageUrl);

    // Simulamos varias posibles respuestas de análisis
    const analyses = [
      "He detectado una forma humanoide en la esquina superior derecha de la imagen. La proporción de sus extremidades no corresponde a la anatomía humana normal.",
      "Hay un rostro parcialmente visible en las sombras detrás de la ventana. Sus rasgos son asimétricos y los ojos parecen reflejar luz de manera no natural.",
      "Se aprecia un patrón de energía extraño alrededor del objeto principal. Las variaciones de temperatura no son consistentes con fenómenos naturales.",
      "Hay una silueta traslúcida que parece atravesar la pared del fondo. Su forma sugiere una figura humana, pero incompleta.",
      "Detecto una anomalía en la estructura temporal de la imagen. Hay elementos que parecen existir en diferentes momentos simultáneamente."
    ];
    
    // Seleccionamos un análisis al azar
    const randomIndex = Math.floor(Math.random() * analyses.length);
    const analysis = analyses[randomIndex];

    return new Response(
      JSON.stringify({
        analysis: analysis,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error en analyze-paranormal-image:', error);
    
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
