
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { prompt } = await req.json();

    // Funcionalidad simulada: en producción, conectaríamos con un servicio de IA como OpenAI
    console.log('Generando historia con el prompt:', prompt);

    // Simulamos una respuesta de la IA (en producción, esto sería una llamada a OpenAI o similar)
    const storyExtension = `${prompt}\n\nLa noche envolvía la casa con su manto de sombras inquietas. El eco de pasos lejanos resonaba en el pasillo, aunque estaba seguro de estar solo. La temperatura descendió súbitamente, y mi aliento se convirtió en vaho frente a mí.\n\nAlgo se movió en la periferia de mi visión. Al girar, solo encontré oscuridad. Pero sabía que había algo allí, observándome con ojos que no eran humanos.\n\nEl sonido de uñas arañando la madera vibró por las paredes. Primero lejos, luego cada vez más cerca. Un aroma a humedad y podredumbre invadió mis fosas nasales. Y entonces, lo vi.\n\nUna figura pálida, contorsionada en ángulos imposibles, emergió lentamente de las sombras. Sus extremidades demasiado largas se extendían hacia mí, mientras una sonrisa demasiado amplia para un rostro humano revelaba hileras de dientes afilados.\n\nIntentó hablar, pero su voz sonaba como un coro de susurros entremezclados, como si muchas entidades habitaran ese mismo cuerpo. Pronunció mi nombre con familiaridad, como si me conociera desde siempre.\n\n"Te he estado esperando", dijo la criatura, mientras inclinaba su cabeza en un ángulo que quebraría el cuello de cualquier ser humano. "Es hora de que vengas conmigo. Todos te esperan al otro lado."`;

    // En producción, aquí iría una llamada a un servicio de IA como OpenAI
    return new Response(
      JSON.stringify({
        story: storyExtension,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error en generate-horror-story:', error);
    
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
