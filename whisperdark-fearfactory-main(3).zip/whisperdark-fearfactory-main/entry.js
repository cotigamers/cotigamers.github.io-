
// This file serves as an entry point for Remix when used with Vite
import { createRequestHandler } from "@remix-run/node";
import * as build from "./build";

const handler = createRequestHandler({
  build,
  mode: process.env.NODE_ENV,
});

export default handler;
